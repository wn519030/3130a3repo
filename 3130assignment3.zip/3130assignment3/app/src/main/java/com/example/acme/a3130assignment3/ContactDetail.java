package com.example.acme.a3130assignment3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.HashMap;

import com.example.acme.a3130assignment3.model.Contact;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class ContactDetail extends AppCompatActivity {

    private TextView name;
    private TextView email;
    private TextView Requires;
    private TextView address;
    private TextView Province;
    private TextView BussinessNo;

    private Button delete;
    private Button update;

    private FirebaseFirestore database;
    private Intent intent;
    private Contact contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_detail);

        name = findViewById(R.id.nameEdit);
        email = findViewById(R.id.emailEdit);
        Requires = findViewById(R.id.Requires);
        address = findViewById(R.id.address);
        Province = findViewById(R.id.Province);
        BussinessNo = findViewById(R.id.BussinessNo);

        delete = findViewById(R.id.deleteButton);
        update = findViewById(R.id.updateButton);

        database = FirebaseFirestore.getInstance();

        intent = getIntent();

        contact = (Contact)intent.getSerializableExtra("contact");
        name.setText(contact.name);
        email.setText(contact.email);
        Requires.setText(contact.Requires);
        address.setText(contact.address);
        Province.setText(contact.Province);
        BussinessNo.setText(contact.BussinessNo);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateContact();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteContact();
            }
        });



    }

    //TODO: add the logic for updating an entry
    private void updateContact()
    {
        String contactNo = contact.id;

        HashMap<String,Object> hm = new HashMap<String,Object>();
        hm.put("name",name.getText().toString());
        hm.put("email",email.getText().toString());
        hm.put("Requires",Requires.getText().toString());
        hm.put("Address",address.getText().toString());
        hm.put("Province",Province.getText().toString());
        hm.put("BussinessNo",BussinessNo.getText().toString());
        database.collection("contacts").document(contactNo).update(hm);

        finish();
    }

    //TODO: add the logic for deleting an entry
    private void deleteContact()
    {

        String contactNo = contact.id;

        HashMap<String,Object> hm1 = new HashMap<String,Object>();
        hm1.remove("name");
        hm1.remove("email");
        hm1.remove("Requires");
        hm1.remove("Address");
        hm1.remove("Province");
        hm1.remove("BussinessNo");
        database.collection("contacts").document(contactNo).delete();
        //finishes the activity
        finish();

    }
}

