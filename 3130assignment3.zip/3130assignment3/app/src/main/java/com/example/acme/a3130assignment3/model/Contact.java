package com.example.acme.a3130assignment3.model;

import java.io.Serializable;

/*
Simple POJO class to hold Contact information
in Realtime database or Firestore database
 */
public class Contact implements Serializable {

    public String id;
    public String name;
    public String email;
    public String Requires;
    public String address;
    public String Province;
    public String BussinessNo;

    public Contact() {

    }

    public Contact(String name, String email, String Requires, String address, String Province, String BussinessNo) {
        this.name = name;
        this.email = email;
        this.Requires = Requires;
        this.Province = Province;
        this.address = address;
        this.BussinessNo = BussinessNo;
    }


    @Override
    public String toString() {
        return "Name: " + name + " e-mail: " + email + "Requires: " + Requires + "Address: " + address + "Province: " + Province + "Bussiness Number: " + BussinessNo;
    }
}
